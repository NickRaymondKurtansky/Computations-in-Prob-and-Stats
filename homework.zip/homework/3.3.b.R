# data
n <- 13
x.bar <- 8.692308

# prior
n.prior <- c(1:50)
shape1 <- 12*n.prior
shape2 <- n.prior
prior.frame <- data.frame(n.prior, shape1, shape2)


# expectation matrix (E = a/b)
E <- matrix(nrow = 50, ncol = 4)
for (i in 1:50){
  E[i,1] <- prior.frame[i,1]
  E[i,2] <- n * x.bar + prior.frame[i,2]
  E[i,3] <- n + prior.frame[i,3]
  E[i,4] <- E[i,2] / E[i,3]
}

plot(E[,1],E[,4], main = "Posterior Expectation by values of n_0", xlab = "n_0 for gamma(12 * n_0, n_0)", ylab = "Posterior Expectation")