# data
trueMu = 10
trueVar = 1.5
n = 23
y = rnorm(n = n,mean = trueMu,sd = sqrt(trueVar))

# prior hyper-parameters
v = 3
S = 6 # will discuss later on how to choose this
Mu0 = 0
varMu = 10000 # flat prior

# parameters of the sample
nIter = 10000 # how many samples do we take with Gibbs sampler

# storage for the samples
mu = rep(NA,nIter)
varY = rep(NA,nIter)

# initialize
meanY = mean(y)
mu[1] = meanY

DF = v + n
RSS = sum((y - mu[1]) ^ 2)
tmpS = S + RSS
varY[1] = tmpS / rchisq(n = 1, df = DF) #initialize

# Gibbs Sampler
for (i in 2:nIter){
  
  # sampling mu given data and variance
    condV = 1 / (n / varY[i-1] + 1 / varMu)
    
    w = n / varY[i-1] * condV
    condMean = w * meanY + (1-w) * Mu0
  
    mu[i] = rnorm(n=1, mean= condMean, sd = sqrt(condV))
  
  # sampling varince given data and mu
    RSS = sum((y - mu[i]) ^ 2)
    tmpS = S + RSS
    varY[i] = tmpS / rchisq(n = 1, df = DF) #initialize
  
  print(i)
}

plot(mu)
plot(mu,cex=.5,col=2,type='o')

plot(varY,cex=.5,col=2,type='o')
