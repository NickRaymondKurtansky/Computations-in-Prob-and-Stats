# a
theta <- seq(1/100, 99/100, by = 1/100)

a = c(5,3)
b = c(5,3)

prior <- function(a,b){
  for (i in 1:length(a)){
    for (j in 1:length(b)){
      title.list <- list("alpha=",a[i]," and beta =", b[j])
      prior.fxn <- theta^(2*a[i] - 1) * exp(-b[j]^2 * theta^2)
      plot(theta, prior.fxn, main = bquote(alpha == .(a[i]) ~ beta == .(b[j])))
    }
  }
}

prior(a,b)
