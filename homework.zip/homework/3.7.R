# a
theta <- seq(from = 1/100, to = 99/100, by = 1/100)
post.fxn <- dbeta(theta,3,14)
plot(theta, post.fxn, main = "Posterior Density", xlab = "theta", ylab = "Density")


# c
y <- c(0:278)
predict.fxn <- choose(278,y)  * 1/beta(3,14) * beta(y+3,292-y)
plot(y,predict.fxn, main = "Predictor distribution vs. y_2", xlab = "y_2", ylab = "Posterior Predictor")

# d
likelihood.fxn <- choose(278,y) * (2/15)^y * (1 - 2/15)^(278-y)
plot(y, likelihood.fxn, main = "Liklihood vs. y_2")
